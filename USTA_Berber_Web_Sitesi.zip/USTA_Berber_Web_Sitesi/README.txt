USTA BARBER WEBSITE
===================

Kurulum:
1. ZIP dosyasını çıkar.
2. index.html dosyasına çift tıklayarak siteyi tarayıcıda aç.
3. İnternete yayınlamak için klasörü Netlify, Vercel veya kendi hosting hesabına yükle.

Özelleştirme:
- İşletme adı: index.html içindeki USTA metinlerini değiştir.
- Telefon / WhatsApp: index.html içindeki +90 555 123 45 67 ve app.js içindeki
  businessNumber = '905551234567' değerlerini kendi numaranla değiştir.
- Adres: index.html içindeki Yakutiye, Erzurum alanını değiştir.
- Hizmet ve fiyatlar: index.html içindeki Hizmetler bölümünü düzenle.
- Çalışma saatleri: üst duyuru bandı ve iletişim bölümünü düzenle.
- Fotoğraflar: HTML/CSS içindeki Unsplash görsel bağlantılarını kendi fotoğraflarınla değiştir.

Özellikler:
- Mobil uyumlu, responsive tasarım
- Hizmet ve fiyat kartları
- Ekip ve galeri bölümleri
- Randevu formu (WhatsApp mesajı oluşturur)
- Telefon ve WhatsApp hızlı iletişim
- Mobil açılır menü
- SEO temel meta etiketleri

ÖNEMLİ:
Bu paket ön yüz (frontend) web sitesidir. Randevular bir veritabanına kaydedilmez;
form, müşterinin bilgilerini WhatsApp mesajı olarak işletmeye hazırlar. Gerçek online
rezervasyon paneli, kullanıcı girişi, yönetici paneli ve veritabanı için backend kurulmalıdır.
