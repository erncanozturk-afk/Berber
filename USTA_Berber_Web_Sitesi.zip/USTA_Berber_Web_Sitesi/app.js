const menuButton = document.querySelector('.menu-toggle');
const nav = document.querySelector('.nav');
menuButton.addEventListener('click', () => {
  const open = nav.classList.toggle('open');
  menuButton.setAttribute('aria-expanded', String(open));
  menuButton.textContent = open ? '×' : '☰';
});
nav.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
  nav.classList.remove('open');
  menuButton.setAttribute('aria-expanded', 'false');
  menuButton.textContent = '☰';
}));
document.getElementById('year').textContent = new Date().getFullYear();

const dateInput = document.querySelector('input[name="date"]');
const today = new Date();
const localDate = new Date(today.getTime() - today.getTimezoneOffset() * 60000).toISOString().slice(0,10);
dateInput.min = localDate;

document.getElementById('bookingForm').addEventListener('submit', function(e) {
  e.preventDefault();
  const data = Object.fromEntries(new FormData(this).entries());
  const phone = data.phone.replace(/\D/g, '');
  if (phone.length < 10) {
    document.getElementById('formFeedback').textContent = 'Lütfen geçerli bir telefon numarası gir.';
    return;
  }
  if (data.date < localDate) {
    document.getElementById('formFeedback').textContent = 'Geçmiş bir tarih seçemezsin.';
    return;
  }
  // İşletme WhatsApp numarasını index.html ve bu satırdaki numarayla değiştirin.
  const businessNumber = '905551234567';
  const message = `Merhaba, randevu talep ediyorum.%0AAd Soyad: ${encodeURIComponent(data.name)}%0ATelefon: ${encodeURIComponent(data.phone)}%0AHizmet: ${encodeURIComponent(data.service)}%0ATarih: ${encodeURIComponent(data.date)}%0ASaat: ${encodeURIComponent(data.time)}%0ANot: ${encodeURIComponent(data.note || '-')}`;
  window.open(`https://wa.me/${businessNumber}?text=${message}`, '_blank', 'noopener');
  document.getElementById('formFeedback').textContent = 'WhatsApp açılıyor. Mesajı göndererek randevu talebini iletebilirsin.';
});
